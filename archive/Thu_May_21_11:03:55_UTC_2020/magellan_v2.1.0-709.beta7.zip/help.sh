#!/bin/sh
cd "$(dirname "$0")"
java -jar "magellan-client.jar" "--help"
